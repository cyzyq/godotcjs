@tool
extends EditorPlugin

# A class member to hold the editor export plugin during its lifecycle.
var export_plugin : AndroidExportPlugin

func _enter_tree():
	# Initialization of the plugin goes here.
	export_plugin = AndroidExportPlugin.new()
	add_export_plugin(export_plugin)


func _exit_tree():
	# Clean-up of the plugin goes here.
	remove_export_plugin(export_plugin)
	export_plugin = null


class AndroidExportPlugin extends EditorExportPlugin:
	# Plugin's name.
	var _plugin_name = "mygodot"

	# Specifies which platform is supported by the plugin.
	func _supports_platform(platform):
		if platform is EditorExportPlatformAndroid:
			return true
		return false

	# Return the paths of the plugin's AAR binaries relative to the 'addons' directory.
	func _get_android_libraries(platform, debug):
		if debug:
			return PackedStringArray(["godotcjs/godot-debug.aar"])
		else:
			return PackedStringArray(["godotcjs/godot-release.aar"])

	# Return the plugin's name.
	func _get_name():
		return _plugin_name
'
if Engine.has_singleton("mygodot"):
	var singleton = Engine.get_singleton("mygodot")
	print(singleton.myPluginFunction("World"))
'
